package com.surface.surfacecore.bedwars;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class bwcommands implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("That command is only available to players");
            return true;
        }
        Player player = (Player) sender;

        if (cmd.getName().equalsIgnoreCase("bwstart")) {

        }

    return true;
    }
}