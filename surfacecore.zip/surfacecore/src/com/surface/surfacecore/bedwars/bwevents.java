package com.surface.surfacecore.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;

public class bwevents implements Listener {

    @EventHandler
    public void onJoinGame(PlayerChangedWorldEvent event) {
        if (event.getPlayer().getWorld() == Bukkit.getWorld("bedwars")) {

        }
    }

}
