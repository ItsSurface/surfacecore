package com.surface.surfacecore.inventories;

import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class Disposal implements InventoryHolder {

    private Inventory inv;

    public Disposal() {
        inv = Bukkit.createInventory(this, 27, "Custom Item Menu");
        init();
    }

    private void init() {

    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
