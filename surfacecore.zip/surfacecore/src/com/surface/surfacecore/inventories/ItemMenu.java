package com.surface.surfacecore.inventories;

import com.surface.surfacecore.items.ItemManager;
import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Item;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.material.Dye;

import java.util.ArrayList;
import java.util.List;

public class ItemMenu implements InventoryHolder {

    private Inventory inv;

    public ItemMenu() {
        inv = Bukkit.createInventory(this, 54, "Custom Item Menu");
        init();
    }

    private void init() {
        ItemStack item;
        inv.setItem(13, ItemManager.beta);
        inv.setItem(21, ItemManager.kbrod);
        inv.setItem(22, ItemManager.kb);
        inv.setItem(23, ItemManager.punch);
        inv.setItem(31, ItemManager.boombaton);
        inv.setItem(30, ItemManager.prop);
        inv.setItem(32, ItemManager.ebow);
        inv.setItem(29, ItemManager.hook);
        inv.setItem(33, ItemManager.aote);
        inv.setItem(37, ItemManager.healscroll);
        inv.setItem(38, ItemManager.lightningscroll);
        inv.setItem(39, ItemManager.tntscroll);
        inv.setItem(40, ItemManager.infinitewater);
        inv.setItem(41, ItemManager.bottomless);
        inv.setItem(42, ItemManager.infinitelava);
        inv.setItem(43, ItemManager.scaffold);
        inv.setItem(49, ItemManager.treecapitator);
        inv.setItem(50, ItemManager.toystick);
        // Panes
        item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.SILVER.getData());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(" ");
        item.setItemMeta(meta);
        inv.setItem(0, item);
        inv.setItem(1, item);
        inv.setItem(2, item);
        inv.setItem(3, item);
        inv.setItem(4, item);
        inv.setItem(5, item);
        inv.setItem(6, item);
        inv.setItem(7, item);
        inv.setItem(8, item);
        inv.setItem(9, item);
        inv.setItem(10, item);
        inv.setItem(11, item);
        inv.setItem(12, item);
        inv.setItem(14, item);
        inv.setItem(15, item);
        inv.setItem(16, item);
        inv.setItem(17, item);
        inv.setItem(18, item);
        inv.setItem(19, item);
        inv.setItem(20, item);
        inv.setItem(24, item);
        inv.setItem(25, item);
        inv.setItem(26, item);
        inv.setItem(27, item);
        inv.setItem(28, item);
        inv.setItem(34, item);
        inv.setItem(35, item);
        inv.setItem(36, item);

        inv.setItem(44, item);
        inv.setItem(45, item);
        inv.setItem(46, item);
        inv.setItem(47, item);
        inv.setItem(48, item);

        inv.setItem(51, item);
        inv.setItem(52, item);
        inv.setItem(53, item);
    }

    private ItemStack createitem(String name, Material mat, List<String> lore) {
        ItemStack item = new ItemStack(mat, 1, DyeColor.SILVER.getData());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
