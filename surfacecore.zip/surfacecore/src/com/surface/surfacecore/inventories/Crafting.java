package com.surface.surfacecore.inventories;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class Crafting implements InventoryHolder {

    private Inventory inv;

    public static ItemStack norecipe;
    public static ItemStack empty;
    public static ItemStack back;
    public static ItemStack quickcraft;

    public Crafting() {
        inv = Bukkit.createInventory(this, 54, "Craft");
        init();
    }

    public void init() {
        ItemStack item;
        item = new ItemStack(Material.BARRIER, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§cRecipe Required");
        List<String> lore = new ArrayList<>();
        lore.add("§7Add the items for a valid");
        lore.add("§7recipe in the crafting grid");
        lore.add("§7to the left!");
        meta.setLore(lore);
        item.setItemMeta(meta);
        norecipe = item;
        inv.setItem(23, item);
        item = new ItemStack(Material.ARROW, 1);
        meta = item.getItemMeta();
        meta.setDisplayName("§aGo Back");
        lore = new ArrayList<>();
        lore.add("§7To Nothing");
        meta.setLore(lore);
        item.setItemMeta(meta);
        back = item;


        inv.setItem(49, item);
        for (int t = 0; t < 3; t++) {
            item = new ItemStack(Material.PAPER, 1);
            meta = item.getItemMeta();
            meta.setDisplayName("§bQuick Craft");
            lore = new ArrayList<>();
            lore.add("§7This feature not yet available");
            meta.setLore(lore);
            item.setItemMeta(meta);
            quickcraft = item;
            inv.setItem(16, item);
            inv.setItem(25, item);
            inv.setItem(34, item);
        }
        for (int i = 0; i < 46; i++) {
            item = new ItemStack(Material.STAINED_GLASS_PANE, 1, DyeColor.SILVER.getData());
            meta = item.getItemMeta();
            meta.setDisplayName(" ");
            item.setItemMeta(meta);
            empty = item;
            inv.setItem(0, item);
            inv.setItem(1, item);
            inv.setItem(2, item);
            inv.setItem(3, item);
            inv.setItem(4, item);
            inv.setItem(5, item);
            inv.setItem(6, item);
            inv.setItem(7, item);
            inv.setItem(8, item);
            inv.setItem(9, item);

            inv.setItem(13, item);
            inv.setItem(14, item);
            inv.setItem(15, item);

            inv.setItem(17, item);
            inv.setItem(18, item);

            inv.setItem(22, item);

            inv.setItem(24, item);

            inv.setItem(26, item);
            inv.setItem(27, item);

            inv.setItem(31, item);
            inv.setItem(32, item);
            inv.setItem(33, item);

            inv.setItem(35, item);
            inv.setItem(36, item);
            inv.setItem(37, item);
            inv.setItem(38, item);
            inv.setItem(39, item);
            inv.setItem(40, item);
            inv.setItem(41, item);
            inv.setItem(42, item);
            inv.setItem(43, item);
            inv.setItem(44, item);
            inv.setItem(45, item);
            inv.setItem(46, item);
            inv.setItem(47, item);
            inv.setItem(48, item);

            inv.setItem(50, item);
            inv.setItem(51, item);
            inv.setItem(52, item);
            inv.setItem(53, item);
        }
    }
    @Override
    public Inventory getInventory() {
        return inv;
    }
}
