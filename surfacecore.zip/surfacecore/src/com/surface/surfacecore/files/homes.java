package com.surface.surfacecore.files;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

public class homes {

    private static File file;
    private static FileConfiguration homes;

    //Find or gen
    public static void setup() {
        file = new File(Bukkit.getServer().getPluginManager().getPlugin("surfacecore").getDataFolder(), "homes.yml");

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                //cuz i have to
            }
        }
        homes = YamlConfiguration.loadConfiguration(file);
    }

    public static FileConfiguration get() {
        return homes;
    }

    public static void save() {
        try {
            homes.save(file);
        } catch (IOException e) {
            System.out.println("Couldn't save file: homes.yml");
        }
    }

    public static void reload() {
        homes = YamlConfiguration.loadConfiguration(file);
    }

}
