package com.surface.surfacecore.items;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import javax.xml.stream.events.Namespace;
import java.util.ArrayList;
import java.util.List;

public class ItemManager {

    public static ItemStack beta;
    public static ItemStack boombaton;
    public static ItemStack kb;
    public static ItemStack punch;
    public static ItemStack prop;
    public static ItemStack ebow;
    public static ItemStack kbrod;
    public static ItemStack hook;
    public static ItemStack aote;
    public static ItemStack infinitewater;
    public static ItemStack infinitelava;
    public static ItemStack bottomless;
    public static ItemStack scaffold;
    public static ItemStack healscroll;
    public static ItemStack lightningscroll;
    public static ItemStack tntscroll;
    public static ItemStack treecapitator;
    public static ItemStack toystick;

    public static void init() {
        createbeta();
        createboombaton();
        createkb();
        createpunch();
        createprop();
        createebow();
        createkbrod();
        createhook();
        createaote();
        createinfinitewater();
        createinfinitelava();
        createbottomless();
        createscaffold();
        createhealscroll();
        createlightningscroll();
        createtntscroll();
        createtreecapitator();
        createtoystick();
    }

    static void item() {
        
    }

    private static void createbeta() {
        ItemStack item = new ItemStack(Material.BLAZE_ROD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§4Beta Stick");
        List<String> lore = new ArrayList<>();
        lore.add("§7This PogChamp of a stick is ");
        lore.add("§7used for testing features for");
        lore.add("§7new items");
        lore.add(" ");
        lore.add("§6Item Ability: Set Fall Distance §e§lRight Click");
        lore.add("§7ack i hope this works");
        lore.add("§8Mana Cost: §3None");
        lore.add("§8Cooldown: §3None");
        lore.add(" ");
        lore.add("§4§lBETA");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        beta = item;
        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape(" B ", " B ", "B B");
        sr.setIngredient('B', Material.BEDROCK);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createboombaton() {
        ItemStack item = new ItemStack(Material.STICK, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§9Boom Baton");
        List<String> lore = new ArrayList<>();
        lore.add("§7DANGER, MAY EXPLODE ON IMPACT");
        lore.add(" ");
        lore.add("§6Item Ability: BOOM §e§lRight Click");
        lore.add("§7Creates an explosion under your");
        lore.add("§7feet which damages the world");
        lore.add("§8Mana Cost: §3None");
        lore.add("§8Cooldown: §3None");
        lore.add(" ");
        lore.add("§6Item Ability: Launch §e§lLeft Click");
        lore.add("§7Creates an explosion under your");
        lore.add("§7feet which sends you flying");
        lore.add("§8Mana Cost: §3None");
        lore.add("§8Cooldown: §3None");
        lore.add(" ");
        lore.add("§9§lRARE");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        boombaton = item;

        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape("TTT", "TST", "TTT");
        sr.setIngredient('S', Material.STICK);
        sr.setIngredient('T', Material.TNT);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createkb() {
        ItemStack item = new ItemStack(Material.STICK, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§aKnockback Stick+");
        List<String> lore = new ArrayList<>();
        lore.add("§7Bonk");
        lore.add(" ");
        lore.add("§a§lUNCOMMON");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.KNOCKBACK, 10, true);
        item.setItemMeta(meta);
        kb = item;

        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape("SSS", "SXS", "SSS");
        sr.setIngredient('X', Material.STICK);
        sr.setIngredient('S', Material.SLIME_BALL);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createpunch() {
        ItemStack item = new ItemStack(Material.BOW, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§aPunch Bow+");
        List<String> lore = new ArrayList<>();
        lore.add("§7Bonk");
        lore.add(" ");
        lore.add("§a§lUNCOMMON");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.ARROW_KNOCKBACK, 10, true);
        meta.spigot().setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        punch = item;

        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape("SSS", "SBS", "SSS");
        sr.setIngredient('B', Material.BOW);
        sr.setIngredient('S', Material.SLIME_BALL);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createkbrod() {
        ItemStack item = new ItemStack(Material.FISHING_ROD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§aKnockback Rod+");
        List<String> lore = new ArrayList<>();
        lore.add("§7Bonk");
        lore.add(" ");
        lore.add("§a§lUNCOMMON");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.KNOCKBACK, 10, true);
        item.setItemMeta(meta);
        kbrod = item;

        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape("SSS", "SFS", "SSS");
        sr.setIngredient('F', Material.FISHING_ROD);
        sr.setIngredient('S', Material.SLIME_BALL);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createprop() {
        ItemStack item = new ItemStack(Material.FEATHER, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§5Propulsion Tool");
        List<String> lore = new ArrayList<>();
        lore.add("§7An item only the most cracked");
        lore.add("§7people can obtain");
        lore.add(" ");
        lore.add("§6Item Ability: Burst §e§lRight Click");
        lore.add("§7Sends you flying in the direction");
        lore.add("§7you're facing");
        lore.add("§8Mana Cost: §3None");
        lore.add("§8Cooldown: §3None");
        lore.add(" ");
        lore.add("§6Item Ability: Hop §e§lLeft Click");
        lore.add("§7Gives you a small upwards boost");
        lore.add("§8Mana Cost: §3None");
        lore.add("§8Cooldown: §3None");
        lore.add(" ");
        lore.add("§5§lEPIC");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        prop = item;

        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape("FGF", "GGG", "FGF");
        sr.setIngredient('F', Material.FEATHER);
        sr.setIngredient('G', Material.SULPHUR);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createebow() {
        ItemStack item = new ItemStack(Material.BOW, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§5Explosive Bow");
        List<String> lore = new ArrayList<>();
        lore.add(" ");
        lore.add("§6Item Ability: Explosive");
        lore.add("§7Creates an explosion on impact!");
        lore.add("§7Every Monster caught in this");
        lore.add("§7explosion takes the full damage");
        lore.add("§7of the weapon");
        lore.add(" ");
        lore.add("§5§lEPIC");
        meta.setLore(lore);
        meta.spigot().setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        ebow = item;

        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape(" TS", "T S", " TS");
        sr.setIngredient('S', Material.STRING);
        sr.setIngredient('T', Material.TNT);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createhook() {
        ItemStack item = new ItemStack(Material.FISHING_ROD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§aGrappling Hook");
        List<String> lore = new ArrayList<>();
        lore.add("§7Travel around in style using");
        lore.add("§7this Grappling Hook");
        lore.add(" ");
        lore.add("§a§lUNCOMMON");
        meta.setLore(lore);
        meta.spigot().setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        hook = item;

        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape("  S", " SX", "S Y");
        sr.setIngredient('S', Material.STICK);
        sr.setIngredient('X', Material.STRING);
        sr.setIngredient('Y', Material.SLIME_BLOCK);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createaote() {
        ItemStack item = new ItemStack(Material.DIAMOND_SWORD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§9Aspect of the End");
        List<String> lore = new ArrayList<>();
        lore.add(" ");
        lore.add("§6Item Ability: Instant Transmission §e§lRIGHT CLICK");
        lore.add("§7Teleport §a8 blocks §7ahead of");
        lore.add("§7you and gain §fSpeed II");
        lore.add("§7for §a3 seconds§7.");
        lore.add("§8Mana Cost: §3None");
        lore.add("§8Cooldown: §3None");
        lore.add(" ");
        lore.add("§9§lRARE");
        meta.setLore(lore);
        meta.spigot().setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        aote = item;

        //Recipe
        ShapedRecipe sr = new ShapedRecipe(item);
        sr.shape("EEE", "EDE", "EEE");
        sr.setIngredient('E', Material.ENDER_CHEST);
        sr.setIngredient('D', Material.DIAMOND_SWORD);
        Bukkit.getServer().addRecipe(sr);
    }
    private static void createinfinitewater() {
        ItemStack item = new ItemStack(Material.WATER_BUCKET, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§aMagical Water Bucket");
        List<String> lore = new ArrayList<>();
        lore.add("§7This Magical Water Bucket will");
        lore.add("§7never run out of water, no");
        lore.add("§7matter how many times it is");
        lore.add("§7emptied.");
        lore.add(" ");
        lore.add("§a§lUNCOMMON");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        infinitewater = item;
    }
    private static void createinfinitelava() {
        ItemStack item = new ItemStack(Material.LAVA_BUCKET, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§aMagical Lava Bucket");
        List<String> lore = new ArrayList<>();
        lore.add("§7This Magical Lava Bucket will");
        lore.add("§7never run out of lava, no");
        lore.add("§7matter how many times it is");
        lore.add("§7emptied.");
        lore.add(" ");
        lore.add("§a§lUNCOMMON");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        infinitelava = item;
    }
    private static void createbottomless() {
        ItemStack item = new ItemStack(Material.BUCKET, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§aBottomless Bucket");
        List<String> lore = new ArrayList<>();
        lore.add("§7This Bottomless Bucket will");
        lore.add("§7never be filled, no matter");
        lore.add("§7how many times you try to");
        lore.add("§7fill it.");
        lore.add(" ");
        lore.add("§a§lUNCOMMON");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        bottomless = item;
    }
    private static void createtoystick() {
        ItemStack item = new ItemStack(Material.STICK, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§5Toy Stick");
        List<String> lore = new ArrayList<>();
        lore.add("§7Parental supervision required");
        lore.add(" ");
        lore.add("§6Item Ability: Magic §e§lRight Click");
        lore.add("§7May cause injury, paralisis, or ");
        lore.add("§7even death");
        lore.add("§8Mana Cost: §3None");
        lore.add("§8Cooldown: §3None");
        lore.add(" ");
        lore.add("§5§lEPIC");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        toystick = item;
    }
    private static void createscaffold() {
        ItemStack item = new ItemStack(Material.BEDROCK, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§6Scaffold");
        List<String> lore = new ArrayList<>();
        lore.add("§7It's just scaffold. (Without");
        lore.add("§7the hacked client part)");
        lore.add(" ");
        lore.add("§6§lLEGENDARY");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        scaffold = item;
    }
    private static void createtreecapitator() {
        ItemStack item = new ItemStack(Material.GOLD_AXE, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§5Treecapitator");
        List<String> lore = new ArrayList<>();
        lore.add("§7A forceful Gold Axe which can");
        lore.add("§7break a large amount of logs in");
        lore.add("§7a single hit");
        lore.add(" ");
        lore.add("§5§lEPIC");
        meta.setLore(lore);
        item.setItemMeta(meta);
        treecapitator = item;
    }
    //Scrolls
    private static void createhealscroll() {
        ItemStack item = new ItemStack(Material.PAPER, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§9Heal Scroll");
        List<String> lore = new ArrayList<>();
        lore.add("§7A mysterious magical scroll...");
        lore.add(" ");
        lore.add("§6Item Ability: Self-Heal §e§lRIGHT CLICK");
        lore.add("§7Instantly heal you to full health");
        lore.add("§7Hmmmm... Strange");
        lore.add("§8One-time use");
        lore.add(" ");
        lore.add("§9§lRARE");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        healscroll = item;
    }
    private static void createlightningscroll() {
        ItemStack item = new ItemStack(Material.PAPER, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§9Lightning Scroll");
        List<String> lore = new ArrayList<>();
        lore.add("§7A mysterious magical scroll...");
        lore.add(" ");
        lore.add("§6Item Ability: Strike §e§lRIGHT CLICK");
        lore.add("§7Summons the powers of Thor where you look");
        lore.add("§7Hmmmm... Strange");
        lore.add("§8One-time use");
        lore.add(" ");
        lore.add("§9§lRARE");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        lightningscroll = item;
    }
    private static void createtntscroll() {
        ItemStack item = new ItemStack(Material.PAPER, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§9TNT Scroll");
        List<String> lore = new ArrayList<>();
        lore.add("§7A mysterious magical scroll...");
        lore.add(" ");
        lore.add("§6Item Ability: Bomb §e§lRIGHT CLICK");
        lore.add("§7Summons the powers of Allahu where you look");
        lore.add("§7Uh Oh...");
        lore.add("§8One-time use");
        lore.add(" ");
        lore.add("§9§lRARE");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        tntscroll = item;
    }
}
