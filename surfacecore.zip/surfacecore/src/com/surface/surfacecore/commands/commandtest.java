package com.surface.surfacecore.commands;

import com.surface.surfacecore.files.homes;
import com.surface.surfacecore.inventories.Crafting;
import com.surface.surfacecore.inventories.Disposal;
import com.surface.surfacecore.inventories.ItemMenu;
import com.surface.surfacecore.items.ItemManager;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.permissions.Permission;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.jar.Attributes;

public class commandtest implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("That command is only available to players");
            return true;
        }
        Player player = (Player) sender;

        // /heal
        if (cmd.getName().equalsIgnoreCase("heal") && player.hasPermission("surface.general.heal")) {
            double maxHealth = player.getMaxHealth();
            player.setHealth(maxHealth);
            player.setFoodLevel(20);
            player.setFireTicks(0);
            player.sendMessage("§f(§a§l+§f) §bHealed");
        }
        // /feed
        else if (cmd.getName().equalsIgnoreCase("feed") && player.hasPermission("surface.general.feed")) {
            player.setFoodLevel(20);
            player.sendMessage("§f(§a§l+§f) §bSaturated");
        }
        // /gamemode
        else if (cmd.getName().equalsIgnoreCase("gamemode")) {
            if (args.length == 1) {
                try {
                    if (GameMode.valueOf(args[0].toUpperCase()) == GameMode.CREATIVE && player.hasPermission("surface.general.gamemode.creative") || GameMode.valueOf(args[0].toUpperCase()) == GameMode.SURVIVAL && player.hasPermission("surface.general.gamemode.survival") || GameMode.valueOf(args[0].toUpperCase()) == GameMode.SPECTATOR && player.hasPermission("surface.general.gamemode.spectator") || GameMode.valueOf(args[0].toUpperCase()) == GameMode.ADVENTURE && player.hasPermission("surface.general.gamemode.adventure")) {
                        player.setGameMode(GameMode.valueOf(args[0].toUpperCase()));
                        player.sendMessage("§f(§a§l+§f) §b" + args[0].toUpperCase().replace("CREATIVE", "Creative").replace("SURVIVAL", "Survival").replace("ADVENTURE", "Adventure").replace("SPECTATOR", "Spectator"));
                    }
                    else {
                        player.sendMessage("§f(§c§l+§f) §bYou do not have permission");
                    }
                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat's not a valid gamemode");
                }
            }
            else if (args.length >= 2) {
                try {
                    Player subject = Bukkit.getPlayer(args[1]);
                    subject.setGameMode(GameMode.valueOf(args[0].toUpperCase()));
                    player.sendMessage("§f(§a§l+§f) §b" + args[0].toUpperCase().replace("CREATIVE", "Creative").replace("SURVIVAL", "Survival").replace("ADVENTURE", "Adventure").replace("SPECTATOR", "Spectator") + " for " + subject.toString().replace("CraftPlayer{name=", "").replace("}", ""));
                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat's not a valid gamemode/player");
                }
            }
            else {
                player.sendMessage("§f(§e§l+§f) §b/gamemode <gamemode>");
            }
        }

        // /gms
        else if (cmd.getName().equalsIgnoreCase("gms") && player.hasPermission("surface.general.gamemode.survival")) {
            if (args.length >= 1){
                try {
                    Player subject = Bukkit.getPlayer(args[0]);
                    subject.setGameMode(GameMode.SURVIVAL);
                    player.sendMessage("§f(§a§l+§f) §bSurvival for " + subject.toString().replace("CraftPlayer{name=", "").replace("}", ""));
                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat's not a valid player");
                }
            }
            else {
                player.setGameMode(GameMode.SURVIVAL);
                player.sendMessage("§f(§a§l+§f) §bSurvival");
            }
        }
        // /gmc
        else if (cmd.getName().equalsIgnoreCase("gmc") && player.hasPermission("surface.general.gamemode.creative")) {
            if (args.length >= 1){
                try {
                    Player subject = Bukkit.getPlayer(args[0]);
                    subject.setGameMode(GameMode.CREATIVE);
                    player.sendMessage("§f(§a§l+§f) §bCreative for " + subject.toString().replace("CraftPlayer{name=", "").replace("}", ""));
                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat's not a valid player");
                }
            }
            else {
                player.setGameMode(GameMode.CREATIVE);
                player.sendMessage("§f(§a§l+§f) §bCreative");
            }
        }
        // /gmsp
        else if (cmd.getName().equalsIgnoreCase("gmsp") && player.hasPermission("surface.general.gamemode.spectator")) {
            if (args.length >= 1){
                try {
                    Player subject = Bukkit.getPlayer(args[0]);
                    subject.setGameMode(GameMode.SPECTATOR);
                    player.sendMessage("§f(§a§l+§f) §bSpectator for " + subject.toString().replace("CraftPlayer{name=", "").replace("}", ""));
                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat's not a valid player");
                }
            }
            else {
                player.setGameMode(GameMode.SPECTATOR);
                player.sendMessage("§f(§a§l+§f) §bSpectator");
            }
        }
        // /gma
        else if (cmd.getName().equalsIgnoreCase("gma") && player.hasPermission("surface.general.gamemode.adventure")) {
            if (args.length >= 1){
                try {
                    Player subject = Bukkit.getPlayer(args[0]);
                    subject.setGameMode(GameMode.ADVENTURE);
                    player.sendMessage("§f(§a§l+§f) §bAdventure for " + subject.toString().replace("CraftPlayer{name=", "").replace("}", ""));
                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat's not a valid player");
                }
            }
            else {
                player.setGameMode(GameMode.ADVENTURE);
                player.sendMessage("§f(§a§l+§f) §bAdventure");
            }
        }
        // /fly
        else if (cmd.getName().equalsIgnoreCase("fly") && player.hasPermission("surface.general.fly")) {
            if (!player.getAllowFlight()) {
                player.setAllowFlight(true);
                player.sendMessage("§f(§a§l+§f) §bFly Enabled");
            } else {
                player.setAllowFlight(false);
                player.sendMessage("§f(§a§l+§f) §bFly Disabled");
            }
        }
        // /clear
        else if (cmd.getName().equalsIgnoreCase("clear")) {
            player.getInventory().clear();
            player.getInventory().setArmorContents(null);
            player.sendMessage("§f(§a§l+§f) §bInventory Cleared");
        }
        // /teleport
        else if (cmd.getName().equalsIgnoreCase("teleport")) {
            if (args.length >= 2) {
                Player tplayer = Bukkit.getPlayer(args[0]);
                Player dplayer = Bukkit.getPlayer(args[1]);
                tplayer.teleport(dplayer.getLocation());
                player.sendMessage("§f(§a§l+§f) §bTeleported §e§n" + tplayer.toString().replace("CraftPlayer{name=", "").replace("}", "") + " §bto §e§n" + dplayer.toString().replace("CraftPlayer{name=", "").replace("}", ""));
            }
            else if (args.length == 1) {
                Player dplayer = Bukkit.getPlayer(args[0]);
                player.teleport(dplayer.getLocation());
                player.sendMessage("§f(§a§l+§f) §bTeleported to §e§n" + dplayer.toString().replace("CraftPlayer{name=", "").replace("}", ""));
            }
            else {
                player.sendMessage("§f(§e§l+§f) §b/teleport <player>");
            }
        }
        // / teleporthere
        else if (cmd.getName().equalsIgnoreCase("teleporthere")) {
            if (args.length >= 1) {
                Player tplayer = Bukkit.getPlayer(args[0]);
                player.teleport(tplayer.getLocation());
                player.sendMessage("§f(§a§l+§f) §bTeleported §e§n" + tplayer.toString().replace("CraftPlayer{name=", "").replace("}", "") + " §bto §e§n" + player.toString().replace("CraftPlayer{name=", "").replace("}", ""));
            }
            else {
                player.sendMessage("§f(§e§l+§f) §b/teleporthere <player>");
            }
        }

        // /disposal

        else if (cmd.getName().equalsIgnoreCase("disposal")) {
            Disposal gui = new Disposal();
            player.openInventory(gui.getInventory());
        }

        // /sethome
        else if (cmd.getName().equalsIgnoreCase("sethome")) {
            if (args.length >= 1) {
                Location loc = player.getLocation();
                List<Integer> sethome = new ArrayList<>();
                sethome.add(loc.getBlockX());
                sethome.add(loc.getBlockY());
                sethome.add(loc.getBlockZ());
                List<Float> yawpitch = new ArrayList<>();
                yawpitch.add(loc.getYaw());
                yawpitch.add(loc.getPitch());
                homes.get().set(player.getUniqueId().toString() + ", " + args[0], sethome);
                homes.get().set(player.getUniqueId().toString() + " yawpitch, " + args[0], yawpitch);
                homes.get().set(player.getUniqueId().toString() + " world, " + args[0], loc.getWorld().toString().replace("CraftWorld{name=", "").replace("}", ""));
                player.sendMessage("§f(§a§l+§f) §bSet home §e§n" + args[0]);
                homes.save();
            }
            else if (args.length == 0) {
                player.sendMessage("§f(§e§l+§f) §b/sethome <home>");
            }
        }
        // /home
        else if (cmd.getName().equalsIgnoreCase("home")) {
            if (args.length >= 1) {
                try {
                    homes.reload();
                    List<Integer> home = homes.get().getIntegerList(player.getUniqueId().toString() + ", " + args[0]);
                    List<Float> yawpitch = homes.get().getFloatList(player.getUniqueId().toString() + " yawpitch, " + args[0]);
                    String homeworld = homes.get().getString(player.getUniqueId().toString() + " world, " + args[0]);
                    Location loc = new Location(Bukkit.getWorld(homeworld), home.get(0), home.get(1), home.get(2), yawpitch.get(0), yawpitch.get(1));
                    player.teleport(loc);
                    player.sendMessage("§f(§a§l+§f) §bTeleported to §e§n" + args[0]);

                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat home doesn't exist");
                }
            }
            else if (args.length == 0) {
                player.sendMessage("§f(§e§l+§f) §b/home <home>");
            }
        }
        // /delhome
        else if (cmd.getName().equalsIgnoreCase("delhome")) {
            if (args.length >= 1) {
                try {
                    homes.reload();
                    homes.get().set(player.getUniqueId().toString() + ", " + args[0], null);
                    homes.get().set(player.getUniqueId().toString() + " yawpitch, " + args[0], null);
                    homes.get().set(player.getUniqueId().toString() + " world, " + args[0], null);
                    player.sendMessage("§f(§a§l+§f) §bDeleted home §e§n" + args[0]);
                    homes.save();
                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat home doesn't exist");
                }
            }
            else if (args.length == 0) {
                player.sendMessage("§f(§e§l+§f) §b/delhome <home>");
            }
        }
        // /smite
        else if (cmd.getName().equalsIgnoreCase("smite")) {
            if (args.length >= 1) {
                Player target = Bukkit.getPlayer(args[0]);
                for (int i = 0; i < 5; i++) {
                    target.getWorld().strikeLightning(target.getLocation());
                }
                player.sendMessage("§f(§a§l+§f) §b" + target.getDisplayName() + "§b has been smitten");
            }
            else if (args.length == 0) {
                for (int i = 0; i < 5; i++) {
                    player.getWorld().strikeLightning(player.getTargetBlock((Set<Material>) null, 20).getLocation());
                }
                player.sendMessage("§f(§a§l+§f) §bSmitten");
            }
        }
        // /strike
        else if (cmd.getName().equalsIgnoreCase("strike")) {
            if (args.length >= 1) {
                Player target = Bukkit.getPlayer(args[0]);
                target.getWorld().strikeLightning(target.getLocation());
            }
            else if (args.length == 0) {
                player.getWorld().strikeLightning(player.getTargetBlock((Set<Material>) null, 20).getLocation());
            }
            player.sendMessage("§f(§a§l+§f) §bLightning Struck");
        }
        // /tnt
        else if (cmd.getName().equalsIgnoreCase("tnt")) {
            Block block = player.getTargetBlock((Set<Material>) null, 100);
            // Get BlockFace
            List<org.bukkit.block.Block> lastTwoTargetBlocks = player.getLastTwoTargetBlocks((Set<Material>) null, 100);
            if (lastTwoTargetBlocks.size() != 2 || !lastTwoTargetBlocks.get(1).getType().isOccluding()) return true;
            org.bukkit.block.Block targetBlock = lastTwoTargetBlocks.get(1);
            org.bukkit.block.Block adjacentBlock = lastTwoTargetBlocks.get(0);
            BlockFace face = targetBlock.getFace(adjacentBlock);
            // Get Block
            int x = block.getX() + face.getModX();
            int y = block.getY() + face.getModY();
            int z = block.getZ() + face.getModZ();
            player.getWorld().spawnEntity(player.getWorld().getBlockAt(x, y, z).getLocation(), EntityType.PRIMED_TNT);
            player.sendMessage("§f(§a§l+§f) §bTNT Spawned");
        }
        // /bomb
        else if (cmd.getName().equalsIgnoreCase("bomb")) {
            Block block = player.getTargetBlock((Set<Material>) null, 100);
            // Get BlockFace
            List<org.bukkit.block.Block> lastTwoTargetBlocks = player.getLastTwoTargetBlocks((Set<Material>) null, 100);
            if (lastTwoTargetBlocks.size() != 2 || !lastTwoTargetBlocks.get(1).getType().isOccluding()) return true;
            org.bukkit.block.Block targetBlock = lastTwoTargetBlocks.get(1);
            org.bukkit.block.Block adjacentBlock = lastTwoTargetBlocks.get(0);
            BlockFace face = targetBlock.getFace(adjacentBlock);
            // Get Block
            int x = block.getX() + face.getModX();
            int y = block.getY() + face.getModY();
            int z = block.getZ() + face.getModZ();
            for (int i = 0; i < 8; i++) {
                player.getWorld().spawnEntity(player.getWorld().getBlockAt(x, y, z).getLocation(), EntityType.PRIMED_TNT);
            }
            player.sendMessage("§f(§a§l+§f) §bBomb Planted");
        }


        // /newworld

        else if (cmd.getName().equalsIgnoreCase("newworld")) {
            WorldCreator c = new WorldCreator(args[0]);
            c.type(WorldType.valueOf(args[1]));
            c.generateStructures(Boolean.parseBoolean(args[2]));
        }

        // /surfacereload
        else if (cmd.getName().equalsIgnoreCase("surfacereload")) {
            homes.reload();
            player.sendMessage("§f(§a§l+§f) §bReloaded config");
        }

        // ITEM COMMANDS
        // /item
        else if (cmd.getName().equalsIgnoreCase("item") && player.hasPermission("surface.items.item")) {
            if (args.length >= 1) {
                int amount = 1;
                if (args.length >= 2) {
                    try {
                        amount = Integer.parseInt(args[1]);
                    } catch (IllegalArgumentException e) {
                        //cuz i have to
                    }
                }
                try {
                    for (int i = 0; i < amount; i++) {
                        if (args[0].equalsIgnoreCase("beta")) {
                            player.getInventory().addItem(ItemManager.beta);
                        } else if (args[0].equalsIgnoreCase("boombaton")) {
                            player.getInventory().addItem(ItemManager.boombaton);
                        } else if (args[0].equalsIgnoreCase("kb")) {
                            player.getInventory().addItem(ItemManager.kb);
                        } else if (args[0].equalsIgnoreCase("punch")) {
                            player.getInventory().addItem(ItemManager.punch);
                        } else if (args[0].equalsIgnoreCase("prop")) {
                            player.getInventory().addItem(ItemManager.prop);
                        } else if (args[0].equalsIgnoreCase("ebow")) {
                            player.getInventory().addItem(ItemManager.ebow);
                        } else if (args[0].equalsIgnoreCase("kbrod")) {
                            player.getInventory().addItem(ItemManager.kbrod);
                        } else if (args[0].equalsIgnoreCase("aote")) {
                            player.getInventory().addItem(ItemManager.aote);
                        } else if (args[0].equalsIgnoreCase("scaffold")) {
                            player.getInventory().addItem(ItemManager.scaffold);
                        } else if (args[0].equalsIgnoreCase("infinitewater")) {
                            player.getInventory().addItem(ItemManager.infinitewater);
                        } else if (args[0].equalsIgnoreCase("infinitelava")) {
                            player.getInventory().addItem(ItemManager.infinitelava);
                        } else if (args[0].equalsIgnoreCase("bottomless")) {
                            player.getInventory().addItem(ItemManager.bottomless);
                        } else if (args[0].equalsIgnoreCase("healscroll")) {
                            player.getInventory().addItem(ItemManager.healscroll);
                        } else if (args[0].equalsIgnoreCase("lightningscroll")) {
                            player.getInventory().addItem(ItemManager.lightningscroll);
                        } else if (args[0].equalsIgnoreCase("tntscroll")) {
                            player.getInventory().addItem(ItemManager.tntscroll);
                        } else if (args[0].equalsIgnoreCase("treecapitator")) {
                            player.getInventory().addItem(ItemManager.treecapitator);
                        } else if (args[0].equalsIgnoreCase("toystick")) {
                            player.getInventory().addItem(ItemManager.toystick);
                        }
                    }
                    player.sendMessage("§f(§a§l+§f) §bItem Given");
                } catch (IllegalArgumentException e) {
                    player.sendMessage("§f(§c§l+§f) §bThat's not a valid custom item");
                }
            }
            else if (args.length == 0) {
                ItemMenu gui = new ItemMenu();
                player.openInventory(gui.getInventory());
            }
        }
        // /craft
        else if (cmd.getName().equalsIgnoreCase("craft")) {
            Crafting gui = new Crafting();
            player.openInventory(gui.getInventory());
        }

        // END
        else {
            player.sendMessage("§f(§c§l+§f) §bYou do not have permission");
        }
    return true;
    }
}
