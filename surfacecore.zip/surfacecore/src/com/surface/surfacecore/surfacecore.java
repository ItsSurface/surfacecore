package com.surface.surfacecore;

import com.surface.surfacecore.bedwars.bwevents;
import com.surface.surfacecore.commands.commandtest;
import com.surface.surfacecore.events.coreevents;
import com.surface.surfacecore.files.homes;
import com.surface.surfacecore.items.ItemManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class surfacecore extends JavaPlugin {

    @Override
    public void onEnable() {
        //Items
        ItemManager.init();
        //Commands
        commandtest commands = new commandtest();
        getCommand("heal").setExecutor(commands);
        getCommand("feed").setExecutor(commands);
        getCommand("gamemode").setExecutor(commands);
        getCommand("gms").setExecutor(commands);
        getCommand("gmc").setExecutor(commands);
        getCommand("gmsp").setExecutor(commands);
        getCommand("gma").setExecutor(commands);
        getCommand("fly").setExecutor(commands);
        getCommand("clear").setExecutor(commands);
        getCommand("item").setExecutor(commands);
        getCommand("craft").setExecutor(commands);
        getCommand("sethome").setExecutor(commands);
        getCommand("home").setExecutor(commands);
        getCommand("delhome").setExecutor(commands);
        getCommand("surfacereload").setExecutor(commands);
        getCommand("teleport").setExecutor(commands);
        getCommand("teleporthere").setExecutor(commands);
        getCommand("smite").setExecutor(commands);
        getCommand("strike").setExecutor(commands);
        getCommand("tnt").setExecutor(commands);
        getCommand("bomb").setExecutor(commands);
        //Events
        getServer().getPluginManager().registerEvents(new coreevents(), this);
        getServer().getPluginManager().registerEvents(new bwevents(), this);
        //Console Messages
        getServer().getConsoleSender().sendMessage(ChatColor.BLUE + "[surfacecore] Plugin enabled");
        //Config Files
        getConfig().options().copyDefaults();
        saveDefaultConfig();
        homes.setup();
        homes.get().addDefault("joe", "mama");
        homes.get().options().copyDefaults(true);
        homes.get();
    }

    @Override
    public void onDisable() {
        getServer().getConsoleSender().sendMessage(ChatColor.BLUE + "[surfacecore] Plugin disabled");
    }

}
