package com.surface.surfacecore.events;

import com.surface.surfacecore.inventories.Crafting;
import com.surface.surfacecore.inventories.ItemMenu;
import com.surface.surfacecore.items.ItemManager;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryInteractEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class coreevents implements Listener {

    public HashMap<Player, Integer> map = new HashMap<>();
    public HashMap<UUID, Integer> map2 = new HashMap<>();
    public HashMap<Integer, Block> tree1 = new HashMap<>();
    public HashMap<Integer, Block> tree2 = new HashMap<>();

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        player.sendMessage(ChatColor.AQUA + "Welcome to the test server! :)");
    }

    @EventHandler
    public void onLeaveBed(PlayerBedLeaveEvent event) {
        Player player = event.getPlayer();
        player.sendMessage(ChatColor.AQUA + "To teleport to your bed, use " + ChatColor.YELLOW + "/home bed");
    }
    //Item Right Clicks
    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.RIGHT_CLICK_AIR) {
            if (event.getItem() != null) {
                if (event.getItem().getItemMeta().equals(ItemManager.boombaton.getItemMeta())) {
                    Player player = event.getPlayer();
                    Block block = player.getTargetBlock((Set<Material>) null, 50);
                    Location loc = new Location(block.getWorld(), block.getX(), block.getY(), block.getZ());
                    String gmsave = player.getGameMode().toString();
                    int yes = 0;
                    if (player.isFlying()) {
                        yes = 1;
                    }
                    player.setGameMode(GameMode.SPECTATOR);
                    if (block.getType() != Material.BEDROCK && block.getType() != Material.BEDROCK && block.getType() != Material.OBSIDIAN && block.getType() != Material.COMMAND && block.getType() != Material.ENDER_PORTAL_FRAME && block.getType() != Material.PORTAL && block.getType() != Material.ENDER_PORTAL && block.getType() != Material.ANVIL && block.getType() != Material.ENCHANTMENT_TABLE && block.getType() != Material.ENDER_CHEST && block.getType() != Material.WATER && block.getType() != Material.LAVA) {
                        block.breakNaturally();
                    }
                    player.getWorld().createExplosion(loc, 3.0f);
                    player.setGameMode(GameMode.valueOf(gmsave));
                    if (yes == 0) {
                        player.setFlying(false);
                    }
                    player.sendMessage("§aUsed §6BOOM §b(No Mana)");
                } else if (event.getItem().getItemMeta().equals(ItemManager.prop.getItemMeta())) {
                    Player player = event.getPlayer();
                    Vector dir = player.getLocation().getDirection();
                    player.setVelocity(dir.multiply(5));
                    player.sendMessage("§aUsed §6Burst §b(No Mana)");
                    map.put(event.getPlayer(), 1);
                } else if (event.getItem().getItemMeta().equals(ItemManager.beta.getItemMeta())) {
                    Player player = event.getPlayer();
                    player.setFallDistance(0);
                } else if (event.getItem().getItemMeta().equals(ItemManager.aote.getItemMeta())) {
                    Player player = event.getPlayer();
                    Block block = player.getTargetBlock((Set<Material>) null, 8);
                    Location loc = new Location(block.getWorld(), block.getX(), block.getY(), block.getZ(), player.getLocation().getYaw(), player.getLocation().getPitch());
                    player.teleport(loc);
                    player.playSound(loc, Sound.ENDERMAN_TELEPORT, 1, 1);
                    player.sendMessage("§aUsed §6Instant Transmission §b(No Mana)");
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 1, true, false));
                } else if (event.getItem().getItemMeta().equals(ItemManager.scaffold.getItemMeta())) {
                    Player player = event.getPlayer();
                    if (map2.get(player.getUniqueId()) == 0) {
                        map2.put(player.getUniqueId(), 1);
                    }
                    else if (map2.get(player.getUniqueId()) == 1) {
                        map2.put(player.getUniqueId(), 0);
                    }
                    else {
                        map2.put(player.getUniqueId(), 1);
                    }
                } else if (event.getItem().getItemMeta().equals(ItemManager.healscroll.getItemMeta())) {
                    Player player = event.getPlayer();
                    double maxHealth = player.getMaxHealth();
                    player.setHealth(maxHealth);
                    player.setFoodLevel(20);
                    player.setFireTicks(0);
                    player.sendMessage("§f(§a§l+§f) §bHealed");
                    player.getInventory().removeItem(ItemManager.healscroll);
                } else if (event.getItem().getItemMeta().equals(ItemManager.tntscroll.getItemMeta())) {
                    Player player = event.getPlayer();
                    Block block = player.getTargetBlock((Set<Material>) null, 100);
                    // Get BlockFace
                    List<Block> lastTwoTargetBlocks = player.getLastTwoTargetBlocks((Set<Material>) null, 100);
                    if (lastTwoTargetBlocks.size() != 2 || !lastTwoTargetBlocks.get(1).getType().isOccluding()) {
                        // idk
                    } else {
                        org.bukkit.block.Block targetBlock = lastTwoTargetBlocks.get(1);
                        org.bukkit.block.Block adjacentBlock = lastTwoTargetBlocks.get(0);
                        BlockFace face = targetBlock.getFace(adjacentBlock);
                        // Get Block
                        int x = block.getX() + face.getModX();
                        int y = block.getY() + face.getModY();
                        int z = block.getZ() + face.getModZ();
                        for (int i = 0; i < 8; i++) {
                            player.getWorld().spawnEntity(player.getWorld().getBlockAt(x, y, z).getLocation(), EntityType.PRIMED_TNT);
                        }
                        player.getInventory().removeItem(ItemManager.tntscroll);
                    }
                } else if (event.getItem().getItemMeta().equals(ItemManager.lightningscroll.getItemMeta())) {
                    Player player = event.getPlayer();
                    player.getWorld().strikeLightning(player.getTargetBlock((Set<Material>) null, 50).getLocation());
                    player.getInventory().removeItem(ItemManager.lightningscroll);
                } else if (event.getItem().getType().equals(Material.FIREBALL)) {
                    Player player = event.getPlayer();
                    player.getWorld().spawnEntity(player.getLocation(), EntityType.FIREBALL);
                } else if (event.getItem().getItemMeta().equals(ItemManager.toystick.getItemMeta())) {
                    Player player = event.getPlayer();
                    Block block = player.getTargetBlock((Set<Material>) null, 100).getRelative(BlockFace.UP);
                    for (int i = 0; i <= 15; i++) {
                        float x = -2.0F + (float)(Math.random() * 2.0D + 1.0D);
                        float y = (float)(Math.random() + 1.0D);
                        float z = -2.0F + (float)(Math.random() * 2.0D + 1.0D);

                        FallingBlock fblock = block.getWorld().spawnFallingBlock(block.getLocation(), Material.SNOW_BLOCK, (byte) 0);
                        fblock.setVelocity(new Vector(x, y, z));
                    }
                    block.getWorld().playSound(block.getLocation(), Sound.FIREWORK_LAUNCH, 1f, 1f);
                    for (Player vplayer : Bukkit.getServer().getOnlinePlayers()) {
                        if (vplayer.getLocation().distance(block.getLocation()) <= 5) {
                            float vx = (float) (vplayer.getLocation().getX() - block.getLocation().getX());
                            float vy = (float) (vplayer.getLocation().getY() - block.getLocation().getY());
                            float vz = (float) (vplayer.getLocation().getZ() - block.getLocation().getZ());
                            vplayer.setVelocity(new Vector(vx, vy, vz));
                        }
                    }

                }
            }
        }
    }
    //Item Left Clicks
    @EventHandler
    public void onLeftClick(PlayerInteractEvent event) {
        if (event.getAction() == Action.LEFT_CLICK_BLOCK || event.getAction() == Action.LEFT_CLICK_AIR) {
            if (event.getItem() != null) {
                if (event.getItem().getItemMeta().equals(ItemManager.boombaton.getItemMeta())) {
                    Player player = event.getPlayer();
                    player.getWorld().createExplosion(player.getLocation(), 0.001f);
                    player.setVelocity(new Vector(0, 20, 0));
                    player.sendMessage("§aUsed §6Launch §b(No Mana)");
                    map.put(event.getPlayer(), 1);
                }
                else if (event.getItem().getItemMeta().equals(ItemManager.prop.getItemMeta())) {
                    Player player = event.getPlayer();
                    player.setVelocity(new Vector(0, 1, 0));
                    player.sendMessage("§aUsed §6Hop §b(No Mana)");
                    map.put(event.getPlayer(), 1);
                }
            }
        }
    }
    //Armor
    /*
    @EventHandler
    public void onArmorEquip(InventoryDragEvent event) {
        Player player = (Player) event.getWhoClicked();
        ItemStack[] armor = player.getInventory().getArmorContents();
        player.sendMessage(armor.toString());
    }

     */


    //Grappling Hook
    //@EventHandler
    //public void onFish(PlayerFishEvent event) {
    //    Player player = event.getPlayer();
    //    ItemStack item = player.getInventory().getItemInHand();
    //    if (item.getItemMeta() == ItemManager.hook.getItemMeta()) {
    //        Location playerLoc = player.getLocation();
    //        Location hookLoc = event.getHook().getLocation();
    //        Location change = hookLoc.subtract(playerLoc);
    //        player.setVelocity(change.toVector().multiply(0.3));
    //    }
    //}

    // Treecap
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (player.getInventory().getItemInHand() == ItemManager.treecapitator && block.getType() == Material.LOG) {
            Block up = block.getRelative(BlockFace.UP);
            Block down = block.getRelative(BlockFace.DOWN);
            Block north = block.getRelative(BlockFace.NORTH);
            Block east = block.getRelative(BlockFace.EAST);
            Block south = block.getRelative(BlockFace.SOUTH);
            Block west = block.getRelative(BlockFace.WEST);
            Integer place = 0;
            if (up.getType() == Material.LOG) {
                tree1.put(place, up);
                place++;
            }
            if (down.getType() == Material.LOG) {
                tree1.put(place, down);
                place++;
            }
            if (north.getType() == Material.LOG) {
                tree1.put(place, north);
                place++;
            }
            if (east.getType() == Material.LOG) {
                tree1.put(place, east);
                place++;
            }
            if (south.getType() == Material.LOG) {
                tree1.put(place, south);
                place++;
            }
            if (west.getType() == Material.LOG) {
                tree1.put(place, west);
                place++;
            }
            for (int i = 0; i > tree1.size(); i++) {
                final int l = i;
                BukkitRunnable task = new BukkitRunnable() {
                    @Override
                    public void run() {
                        tree1.get(l).breakNaturally();
                    }
                };
                task.runTaskLater((Plugin) this, i * 5);
            }
            // Run the task on this plugin in 3 seconds (60 ticks)
            /*
            for (int ii = 0; ii > 5; ii++) {
                tree2.clear();
                tree2.putAll(tree1);
                tree1.clear();
                for (int i = 0; i < tree2.size(); i++) {
                    block = tree2.get(i);
                    up = block.getRelative(BlockFace.UP);
                    down = block.getRelative(BlockFace.DOWN);
                    north = block.getRelative(BlockFace.NORTH);
                    east = block.getRelative(BlockFace.EAST);
                    south = block.getRelative(BlockFace.SOUTH);
                    west = block.getRelative(BlockFace.WEST);
                    place = 0;
                    if (up.getType() == Material.LOG) {
                        tree1.put(place, up);
                        place++;
                    }
                    if (down.getType() == Material.LOG) {
                        tree1.put(place, down);
                        place++;
                    }
                    if (north.getType() == Material.LOG) {
                        tree1.put(place, north);
                        place++;
                    }
                    if (east.getType() == Material.LOG) {
                        tree1.put(place, east);
                        place++;
                    }
                    if (south.getType() == Material.LOG) {
                        tree1.put(place, south);
                        place++;
                    }
                    if (west.getType() == Material.LOG) {
                        tree1.put(place, west);
                        place++;
                    }
                }
            }

             */
        }
    }
    //Toy Stick
    @EventHandler
    public void onFall(EntityChangeBlockEvent event) {
        if (event.getTo() == Material.SNOW_BLOCK) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrop(ItemSpawnEvent event) {
        if (event.getEntity().getItemStack().equals(new ItemStack(Material.SNOW_BLOCK, 1))) {
            event.setCancelled(true);
        }
    }

    //Explosive Bow
    @EventHandler
    public void onArrow(ProjectileHitEvent event) {
        Arrow arrow = (Arrow) event.getEntity();
        Player player = (Player) arrow.getShooter();
        ItemStack item = player.getInventory().getItemInHand();
        ItemMeta meta = item.getItemMeta();
        Location arrowloc = arrow.getLocation();
        World world = player.getWorld();
        if (meta == ItemManager.ebow.getItemMeta()); {
            world.createExplosion(arrowloc.getX(), arrowloc.getY(), arrowloc.getZ(), 3, false, false);
        }
    }
    //Buckets
    @EventHandler
    public void onBucketDrain(PlayerBucketEmptyEvent event) {
        Player player = event.getPlayer();
        int x = event.getBlockClicked().getX() + event.getBlockFace().getModX();
        int y = event.getBlockClicked().getY() + event.getBlockFace().getModY();
        int z = event.getBlockClicked().getZ() + event.getBlockFace().getModZ();
        if (player.getInventory().getItemInHand().getItemMeta().getDisplayName() == ItemManager.infinitewater.getItemMeta().getDisplayName()) {
            event.getPlayer().getWorld().getBlockAt(x, y, z).setType(Material.WATER);
            event.setCancelled(true);
        }
        else if (player.getInventory().getItemInHand().getItemMeta().getDisplayName() == ItemManager.infinitelava.getItemMeta().getDisplayName()) {
            event.getPlayer().getWorld().getBlockAt(x, y, z).setType(Material.LAVA);
            event.setCancelled(true);
        }
    }
    @EventHandler
    public void onBucketFill(PlayerBucketFillEvent event) {
        Player player = event.getPlayer();
        int x = event.getBlockClicked().getX();
        int y = event.getBlockClicked().getY();
        int z = event.getBlockClicked().getZ();

        if (player.getInventory().getItemInHand().getItemMeta().getDisplayName() == ItemManager.bottomless.getItemMeta().getDisplayName()) {
            player.getWorld().getBlockAt(x, y, z).setType(Material.AIR);
            event.setCancelled(true);
        }
    }

    //Scaffold
    /*
    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        if (event.getPlayer().getInventory().getItemInHand().getItemMeta() == ItemManager.scaffold.getItemMeta() && event.getPlayer().getLocation().getBlock().getRelative(BlockFace.DOWN).getType() == Material.AIR) {
            event.getPlayer().getLocation().getBlock().getRelative(BlockFace.DOWN).setType(Material.GLASS);
        }
    }

     */

    //Damage Cancelations
    @EventHandler
    public void onPlayerDamage(EntityDamageEvent event){
        if(event.getCause() == EntityDamageEvent.DamageCause.FALL && map.get(event.getEntity()) == 1) {
            event.setCancelled(true);
            map.put((Player) event.getEntity(), 0);
        }
    }
    //Inventories
    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getClickedInventory() == null) {
            return;
        }
        Player player = (Player) event.getWhoClicked();
        //ItemMenu
        if (event.getClickedInventory().getHolder() instanceof ItemMenu) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null) {
                return;
            }
            if (event.getSlot() == 13) {
                player.getInventory().addItem(ItemManager.beta);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 31) {
                player.getInventory().addItem(ItemManager.boombaton);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 22) {
                player.getInventory().addItem(ItemManager.kb);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 23) {
                player.getInventory().addItem(ItemManager.punch);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 30) {
                player.getInventory().addItem(ItemManager.prop);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 32) {
                player.getInventory().addItem(ItemManager.ebow);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 21) {
                player.getInventory().addItem(ItemManager.kbrod);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 29) {
                player.getInventory().addItem(ItemManager.hook);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 33) {
                player.getInventory().addItem(ItemManager.aote);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 37) {
                player.getInventory().addItem(ItemManager.healscroll);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 38) {
                player.getInventory().addItem(ItemManager.lightningscroll);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 39) {
                player.getInventory().addItem(ItemManager.tntscroll);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 40) {
                player.getInventory().addItem(ItemManager.infinitewater);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 41) {
                player.getInventory().addItem(ItemManager.bottomless);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 42) {
                player.getInventory().addItem(ItemManager.infinitelava);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 43) {
                player.getInventory().addItem(ItemManager.scaffold);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 49) {
                player.getInventory().addItem(ItemManager.treecapitator);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            } else if (event.getSlot() == 50) {
                player.getInventory().addItem(ItemManager.toystick);
                player.sendMessage("§f(§a§l+§f) §bItem Given");
            }

        }
        // Crafting
        /*
        if (event.getClickedInventory().getHolder() instanceof Crafting) {
            Inventory inv = event.getClickedInventory();
            if (event.getCurrentItem().getItemMeta().getDisplayName() == Crafting.empty.getItemMeta().getDisplayName() || event.getCurrentItem().getItemMeta().getDisplayName() == Crafting.quickcraft.getItemMeta().getDisplayName() || event.getCurrentItem().getItemMeta().getDisplayName() == Crafting.norecipe.getItemMeta().getDisplayName() || event.getCurrentItem().getItemMeta().getDisplayName() == Crafting.back.getItemMeta().getDisplayName()) {
                event.setCancelled(true);
            }
            if (inv.getItem(20) == ItemManager.kb) {
                player.sendMessage("§b§lgamer moment");
            }
        }

         */
    }
    /*
    @EventHandler
    public void onAddItem(InventoryInteractEvent event) {

    }

     */
}
